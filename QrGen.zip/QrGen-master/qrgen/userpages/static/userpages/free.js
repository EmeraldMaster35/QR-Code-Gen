let cancel = document.querySelector(".cancel")
let inpChecker = document.querySelector(".aboba")

if (inpChecker.value === "Free"){

    cancel.style = "display: none"

}
else{

    cancel.style = "display: flex"

}