from django.contrib import admin
from .models import UserMod, Plan

# Register your models here.
admin.site.register(UserMod)
admin.site.register(Plan)