from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(QrCode)
admin.site.register(UserImage)
admin.site.register(LittleImage)