from django.apps import AppConfig


class FirstpagesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'firstpages'
